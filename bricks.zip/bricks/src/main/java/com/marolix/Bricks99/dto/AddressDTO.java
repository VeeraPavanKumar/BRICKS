package com.marolix.Bricks99.dto;

public class AddressDTO {
	private Integer addressId;
	private String surveyNo;
	 private String Locality;
	private double areaInSqft;
	private Integer pinCode;
	private String state;

	public AddressDTO() {
	}


	public AddressDTO(Integer addressId, String surveyNo, String Locality, double areaInSqft, Integer pinCode,
			String state) {
		super();
		this.addressId = addressId;
		this.surveyNo = surveyNo;
		this.Locality = Locality;
		this.areaInSqft = areaInSqft;
		this.pinCode = pinCode;
		this.state = state;
	}


	public Integer getAddressId() {
		return addressId;
	}

	public void setAddressId(Integer addressId) {
		this.addressId = addressId;
	}

	public String getSurveyNo() {
		return surveyNo;
	}

	public void setSurveyNo(String surveyNo) {
		this.surveyNo = surveyNo;
	}

	public double getAreaInSqft() {
		return areaInSqft;
	}

	public void setAreaInSqft(double areaInSqft) {
		this.areaInSqft = areaInSqft;
	}

	public Integer getPinCode() {
		return pinCode;
	}

	public String getLocality() {
		return Locality;
	}


	public void setLocality(String Locality) {
		this.Locality = Locality;
	}


	public void setPinCode(Integer pinCode) {
		this.pinCode = pinCode;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

}
