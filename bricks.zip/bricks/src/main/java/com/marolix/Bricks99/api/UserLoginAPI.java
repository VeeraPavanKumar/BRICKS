package com.marolix.Bricks99.api;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.marolix.Bricks99.dto.UserLoginDTO;
import com.marolix.Bricks99.exception.Bricks99Exception;
import com.marolix.Bricks99.service.UserLoginService;

@RestController
@Validated
@RequestMapping(value = "login-api")
public class UserLoginAPI {

	@Autowired
	private UserLoginService userLoginService;

	@PostMapping(value = "/login")
	public ResponseEntity<String> validLogin(@RequestParam String email,@Valid@RequestBody UserLoginDTO loginDTO) throws Bricks99Exception {
		System.out.println(loginDTO);
		String b = userLoginService.validLogin(email,loginDTO);
		return new ResponseEntity<>(b, HttpStatus.OK);
	}
//	@PostMapping(value = "/login")
//	public ResponseEntity<UserLoginDTO> Registeration(@RequestBody UserLoginDTO loginDTO) throws Bricks99Exception {
//	    UserLoginDTO b = userLoginService.registerUser(loginDTO);
//	    return new ResponseEntity<UserLoginDTO>(b, HttpStatus.OK);
//	}

    @PostMapping("/register")
    public ResponseEntity<UserLoginDTO> Registeration(@Valid@RequestBody UserLoginDTO loginDTO) {
        // Log the incoming request data
        System.out.println("Received request data: " + loginDTO);

        try {
            UserLoginDTO registeredUser = userLoginService.registerUser(loginDTO);
            return new ResponseEntity<UserLoginDTO>(registeredUser, HttpStatus.CREATED);
        } catch (Bricks99Exception e) {
            return new ResponseEntity<UserLoginDTO>(HttpStatus.BAD_REQUEST);
        }
    }

@PutMapping(value = "/update")
public ResponseEntity<String>updateuser(
		@RequestParam String Phonenumber,@Valid @RequestBody UserLoginDTO dto) throws Bricks99Exception {
	String Propertyprice = userLoginService.updateUserPhoneNumber(Phonenumber,dto);
		
	return new ResponseEntity<String>(Propertyprice, HttpStatus.OK);
}

@DeleteMapping(value = "/delete")
public ResponseEntity<String>deleteuser(
		@RequestParam String Phonenumber, @Valid@RequestBody UserLoginDTO dto) throws Bricks99Exception {
	String Propertyprice = userLoginService.deleteUserAccount(Phonenumber, dto);
		
	return new ResponseEntity<String>(Propertyprice, HttpStatus.OK);
}





}
