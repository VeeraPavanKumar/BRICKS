  package com.marolix.Bricks99.service;

import com.marolix.Bricks99.dto.UserLoginDTO;
import com.marolix.Bricks99.exception.Bricks99Exception;

public interface UserLoginService {
	public String  validLogin(String email,UserLoginDTO dto) throws Bricks99Exception ;
public UserLoginDTO registerUser(UserLoginDTO dto)throws Bricks99Exception;
public String updateUserEmail(UserLoginDTO dto)throws Bricks99Exception;
public String updateUserPhoneNumber(String PhoneNumber,UserLoginDTO dto) throws Bricks99Exception;
public String deleteUserAccount(String PhoneNumber,UserLoginDTO dto) throws Bricks99Exception ;
}
