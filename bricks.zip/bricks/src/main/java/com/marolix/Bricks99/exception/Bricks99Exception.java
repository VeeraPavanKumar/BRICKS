package com.marolix.Bricks99.exception;

public class Bricks99Exception extends Exception{
/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

public Bricks99Exception(String message) {
	super(message);
}
}
