package com.marolix.Bricks99.entity;

import javax.persistence.*;

@Entity
@Table(name = "Address")
public class AddressEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "AddressId")
    private Integer addressId;

    @Column(unique = true)
    private String surveyNo;

    @Column(name = "Locality")
    private String locality;

    @Column(name = "areaInSqft")
    private double areaInSqft;

    @Column(name = "PinCode")
    private Integer pinCode;

    @Column(name = "State")
    private String state;

    public AddressEntity() {
        super();
    }

    public AddressEntity(String surveyNo, String locality, double areaInSqft, Integer pinCode, String state) {
        super();
        this.surveyNo = surveyNo;
        this.locality = locality;
        this.areaInSqft = areaInSqft;
        this.pinCode = pinCode;
        this.state = state;
    }

    public Integer getAddressId() {
        return addressId;
    }

    public void setAddressId(Integer addressId) {
        this.addressId = addressId;
    }

    public String getSurveyNo() {
        return surveyNo;
    }

    public void setSurveyNo(String surveyNo) {
        this.surveyNo = surveyNo;
    }

    public String getLocality() {
        return locality;
    }

    public void setLocality(String locality) {
        this.locality = locality;
    }

    public double getAreaInSqft() {
        return areaInSqft;
    }

    public void setAreaInSqft(double areaInSqft) {
        this.areaInSqft = areaInSqft;
    }

    public Integer getPinCode() {
        return pinCode;
    }

    public void setPinCode(Integer pinCode) {
        this.pinCode = pinCode;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }
}
