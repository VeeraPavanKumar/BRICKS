package com.marolix.Bricks99.dto;

import org.springframework.lang.NonNull;

public class UserLoginDTO {
	@NonNull
	
    private Integer id;
	@NonNull
    private String username;  
	// Change this field name to "username"
	@NonNull
    private UserRole userrole;
	@NonNull
    private String Phonenumber;
	@NonNull
    private String email;
	@NonNull
    private String password;

	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public UserRole getUserrole() {
		return userrole;
	}
	public void setUserrole(UserRole userrole) {
		this.userrole = userrole;
	}
	public String getPhonenumber() {
		return Phonenumber;
	}
	public void setPhonenumber(String Phonenumber) {
		this.Phonenumber = Phonenumber;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	@Override
	public String toString() {
		return "UserLoginDTO [id=" + id + ", username=" + username + ", userrole=" + userrole + ", Phonenumber="
				+ Phonenumber + ", email=" + email + ", password=" + password + "]";
	}
	
}