package com.marolix.Bricks99.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.marolix.Bricks99.dto.AddressDTO;
import com.marolix.Bricks99.dto.PropertyDetailsDTO;
import com.marolix.Bricks99.entity.AddressEntity;
import com.marolix.Bricks99.entity.PropertyDetailsEntity;
import com.marolix.Bricks99.exception.Bricks99Exception;
import com.marolix.Bricks99.repository.AddressRepository;
import com.marolix.Bricks99.repository.PropertyRepository;

@Service
public class PropertyServiceImpl implements PropertyService {

	@Autowired
	private PropertyRepository propertyRepo;
	@Autowired
	private AddressRepository addressRepo;

	@Override
	public PropertyDetailsDTO addProperty(PropertyDetailsDTO propertyDto) throws Bricks99Exception {
		List<PropertyDetailsEntity> propertyEntity = propertyRepo
				.findByAddressEntitySurveyNo(propertyDto.getAddressdto().getSurveyNo());

		if (!propertyEntity.isEmpty()) {
			throw new Bricks99Exception("AddressSurveyNumberalreadyExists");
		}

		AddressDTO addressDto = propertyDto.getAddressdto();
		AddressEntity newAddress = new AddressEntity(addressDto.getSurveyNo(), addressDto.getLocality(),
				addressDto.getAreaInSqft(), addressDto.getPinCode(), addressDto.getState());
		AddressEntity addedAddress = addressRepo.save(newAddress);

		PropertyDetailsEntity newProperty = new PropertyDetailsEntity(propertyDto.getPropertyName(),
				propertyDto.getPropertyType(), propertyDto.getPropertyPrice(), propertyDto.getNumberOfRooms(),
				addedAddress);

		PropertyDetailsEntity addedProperty = propertyRepo.save(newProperty);

		AddressDTO addedAddressDto = new AddressDTO(addedAddress.getAddressId(), addedAddress.getSurveyNo(),
				addedAddress.getLocality(), addedAddress.getAreaInSqft(), addedAddress.getPinCode(),
				addedAddress.getState());

		return new PropertyDetailsDTO(addedProperty.getPropertyId(), addedProperty.getPropertyName(),
				addedProperty.getPropertyType(), addedProperty.getPropertyPrice(), addedProperty.getNumberOfRooms(),
				addedAddressDto);
	}

	@Override
	public List<PropertyDetailsDTO> findAllPropertiesUsingPagination(int pageNumber, int pageSize)
			throws Bricks99Exception {
		Pageable pageable = PageRequest.of(pageNumber, pageSize);

		Page<PropertyDetailsEntity> propertyPage = propertyRepo.findAll(pageable);
		if (propertyPage.hasContent()) {
			List<PropertyDetailsEntity> propertyList = propertyPage.getContent();
			return propertyList.stream().map(property -> {
				AddressEntity address = property.getAddressEntity();
				AddressDTO addressDTO = new AddressDTO(address.getAddressId(), address.getSurveyNo(),
						address.getLocality(), address.getAreaInSqft(), address.getPinCode(), address.getState());
				return new PropertyDetailsDTO(property.getPropertyId(), property.getPropertyName(),
						property.getPropertyType(), property.getPropertyPrice(), property.getNumberOfRooms(),
						addressDTO);
			}).collect(Collectors.toList());
		}
		throw new Bricks99Exception("No Properties found");
	}
	@Override
	public List<PropertyDetailsDTO> findByLocalityName(String localityName) throws Bricks99Exception {
	    List<PropertyDetailsEntity> propertyList = propertyRepo.findByAddressEntityLocality(localityName);

	    if (propertyList.isEmpty()) {
	        throw new Bricks99Exception("Property with the given locality not found");
	    }

	    List<PropertyDetailsDTO> propertyDTOList = propertyList.stream().map(property -> new PropertyDetailsDTO(
	            property.getPropertyId(), property.getPropertyName(), property.getPropertyType(),
	            property.getPropertyPrice(), property.getNumberOfRooms(),
	            new AddressDTO(property.getAddressEntity().getAddressId(), property.getAddressEntity().getSurveyNo(),
	                    property.getAddressEntity().getLocality(), property.getAddressEntity().getAreaInSqft(),
	                    property.getAddressEntity().getPinCode(), property.getAddressEntity().getState())))
	            .collect(Collectors.toList());

	    return propertyDTOList;
	}

	@Override
	public List<PropertyDetailsDTO> findByPropertyPrice(double price) throws Bricks99Exception {
		 List<PropertyDetailsEntity> propertyList = propertyRepo.findByPropertyPriceLessThanEqual(price);
		 if (propertyList.isEmpty()) {
		        throw new Bricks99Exception("Property with the given Price not found");
		    }
		 List<PropertyDetailsDTO> propertyDTOList = propertyList.stream().map(property -> new PropertyDetailsDTO(
		            property.getPropertyId(), property.getPropertyName(), property.getPropertyType(),
		            property.getPropertyPrice(), property.getNumberOfRooms(),
		            new AddressDTO(property.getAddressEntity().getAddressId(), property.getAddressEntity().getSurveyNo(),
		                    property.getAddressEntity().getLocality(), property.getAddressEntity().getAreaInSqft(),
		                    property.getAddressEntity().getPinCode(), property.getAddressEntity().getState())))
		            .collect(Collectors.toList());

		return propertyDTOList;
	}


}
