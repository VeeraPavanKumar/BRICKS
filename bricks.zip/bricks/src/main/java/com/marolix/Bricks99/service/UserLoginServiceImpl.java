package com.marolix.Bricks99.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.marolix.Bricks99.dto.UserLoginDTO;
import com.marolix.Bricks99.entity.UserBackUp;
import com.marolix.Bricks99.entity.UserLogin;
import com.marolix.Bricks99.exception.Bricks99Exception;
import com.marolix.Bricks99.repository.UserBackUpRepository;
import com.marolix.Bricks99.repository.UserLoginRepository;

@Component
public class UserLoginServiceImpl implements UserLoginService {

	@Autowired
	public UserLoginRepository userLoginRepository;
	@Autowired
	public UserBackUpRepository userBackUpRepository;

	@Override
	public String  validLogin(UserLoginDTO dto) throws Bricks99Exception {

		UserLogin ulogin = userLoginRepository.findByUsername(dto.getUsername());
		if(ulogin==null)throw new Bricks99Exception("user not registered");
		if (dto.getUsername().equals(ulogin.getUsername()) && dto.getPassword().equals(ulogin.getPassword())) {
			return "login successful";
		} else
			throw new Bricks99Exception("Invalid login");

	}
	@Override
	public UserLoginDTO registerUser(UserLoginDTO dto) throws Bricks99Exception {
	    UserLogin user = userLoginRepository.findByEmail(dto.getEmail());

	    if (user != null) {
	        throw new Bricks99Exception("email is already in use");
	    } else {
	        // Create a new user instance and save it
	        UserLogin user1 = new UserLogin();
	        user1.setUsername(dto.getUsername());
	        user1.setPassword(dto.getPassword());
	        user1.setEmail(dto.getEmail());
	        user1.setPhonenumber(dto.getPhonenumber());
	        user1.setUserrole(dto.getUserrole());

	        userLoginRepository.save(user1);

	        return dto;
	    }
	}


	
	@Override
	public String updateUserEmail(UserLoginDTO dto) throws Bricks99Exception {
	    UserLogin user = userLoginRepository.findByEmail(dto.getEmail());

	    if (user == null) {
	        throw new Bricks99Exception("User not found");
	    }

	    if (!user.getUsername().equals(dto.getUsername())) {
	        throw new Bricks99Exception("Provided username does not match the username in the database");
	    }
	    else {
	    user.setEmail(dto.getEmail());
	    userLoginRepository.save(user);

	    return "email updated successfully";
	    }
	}

	@Override
	public String updateUserPhoneNumber(UserLoginDTO dto) throws Bricks99Exception {
		UserLogin user = userLoginRepository.findByUsername(dto.getUsername());

	    if (user == null) {
	        throw new Bricks99Exception("User not found");
	    }

	    if (!user.getUsername().equals(dto.getUsername())) {
	        throw new Bricks99Exception("Provided username does not match the username in the database");
	    }
	    else {
	    user.setPhonenumber(dto.getPhonenumber());
	    userLoginRepository.save(user);

	    return "email updated successfully";
	    }
	}
	@Override
	public String deleteUserAccount(UserLoginDTO dto) throws Bricks99Exception {
	    UserLogin user = userLoginRepository.findByUsername(dto.getUsername());

	    if (user == null) {
	        throw new Bricks99Exception("User not found");
	    } else {
	        UserBackUp backup = new UserBackUp();
	        backup.setUser_id(user.getId());
	        backup.setUserRole(user.getUserrole());
	        backup.setEmail(user.getEmail());
	        backup.setPhoneNumber(user.getPhonenumber());
	        backup.setUserName(user.getUsername());
	        backup.setPassword(user.getPassword());
	        userBackUpRepository.save(backup);	        
	        userLoginRepository.delete(user);
	        return "User deleted successfully and backup created";
	    }
	}


	}


	



