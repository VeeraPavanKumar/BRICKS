package com.marolix.Bricks99.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.marolix.Bricks99.dto.UserLoginDTO;
import com.marolix.Bricks99.entity.UserBackUp;
import com.marolix.Bricks99.entity.UserLogin;
import com.marolix.Bricks99.exception.Bricks99Exception;
import com.marolix.Bricks99.repository.UserBackUpRepository;
import com.marolix.Bricks99.repository.UserLoginRepository;

@Component
public class UserLoginServiceImpl implements UserLoginService {

	@Autowired
	public UserLoginRepository userLoginRepository;
	@Autowired
	public UserBackUpRepository userBackUpRepository;

	@Override
	public String  validLogin(String email,UserLoginDTO dto) throws Bricks99Exception {

		UserLogin ulogin = userLoginRepository.findByEmail(email);
		if(ulogin==null)throw new Bricks99Exception("user not registered");
		if (dto.getFirstName().equals(ulogin.getFirstName()) && dto.getPassword().equals(ulogin.getPassword())) {
			return "login successful";
		} else
			throw new Bricks99Exception("Invalid login");

	}
	@Override
	public UserLoginDTO registerUser(UserLoginDTO dto) throws Bricks99Exception {

		UserLogin sr = userLoginRepository.findByContact(dto.getContact());
		if (sr != null)
			throw new Bricks99Exception("UserService.Phone_Exists");
		UserLogin sr2 = userLoginRepository.findByEmail(dto.getEmail());
		if (sr2 != null)
			throw new Bricks99Exception("UserService.Email_Exists");
		UserLogin user = new UserLogin();
		user.setUserId(dto.getUserId());
		user.setFirstName(dto.getFirstName());
		user.setLastName(dto.getLastName());
		user.setContact(dto.getContact());
		user.setEmail(dto.getEmail());
		user.setPassword(dto.getPassword());
		user.setUserrole(dto.getUserrole());
		
		
		user = userLoginRepository.save(user);
		//System.out.println(user);

		
		return dto;
	}


	
	@Override
	public String updateUserEmail(UserLoginDTO dto) throws Bricks99Exception {
	    UserLogin user = userLoginRepository.findByEmail(dto.getEmail());

	    if (user == null) {
	        throw new Bricks99Exception("User not found");
	    }

	    if (!user.getFirstName().equals(dto.getFirstName())) {
	        throw new Bricks99Exception("Provided username does not match the username in the database");
	    }
	    else {
	    user.setEmail(dto.getEmail());
	    userLoginRepository.save(user);

	    return "email updated successfully";
	    }
	}

	@Override
	public String updateUserPhoneNumber(String PhoneNumber,UserLoginDTO dto) throws Bricks99Exception {
		UserLogin user = userLoginRepository.findByContact(PhoneNumber);
		
	    if (user == null) {
	        throw new Bricks99Exception("User not found");
	    }

//	    if (user.getFirstName().equals(dto.getFirstName())) {
//	        throw new Bricks99Exception("Provided username already exists in the database");
//	    }
	    else {
	    	user.setFirstName(dto.getFirstName());
	    	user.setLastName(dto.getLastName());
	    	user.setEmail(dto.getEmail());
	    user.setContact(dto.getContact());
	    user.setPassword(dto.getPassword());
	    user.setUserrole(dto.getUserrole());
	    userLoginRepository.save(user);

	    return "user updated successfully";
	    }
	}
	@Override
	public String deleteUserAccount(String PhoneNumber,UserLoginDTO dto) throws Bricks99Exception {
	    UserLogin user = userLoginRepository.findByContact(dto.getContact());

	    if (user == null) {
	        throw new Bricks99Exception("User not found");
	    } else {
	        UserBackUp backup = new UserBackUp();
	        backup.setUser_id(user.getUserId());
	        
	        backup.setEmail(user.getEmail());
	        backup.setcontact(user.getContact());
	        backup.setFirstname(user.getFirstName());
	        backup.setLastname(user.getLastName());
	        backup.setcontact(user.getContact());
	        backup.setPassword(user.getPassword());
	        backup.setUserRole(user.getUserrole());
	        userBackUpRepository.save(backup);	        
	        userLoginRepository.delete(user);
	        return "User deleted successfully and backup created";
	    }
	}


	}


	



