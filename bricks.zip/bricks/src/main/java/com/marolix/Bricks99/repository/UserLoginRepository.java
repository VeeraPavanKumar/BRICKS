package com.marolix.Bricks99.repository;


import org.springframework.data.repository.CrudRepository;

import com.marolix.Bricks99.entity.UserLogin;

public interface UserLoginRepository extends CrudRepository<UserLogin, Integer> {
	//select * from user_login where user_name="";QueryApproach
	//@Query(select * from user_login where user_name="";)
	//findDetilsBasedOnUserName();
	UserLogin findByContact(String contact);
//List<UserLogin> findByUserRole(String userRole);
	UserLogin findByEmail(String email);
	   
}
