package com.marolix.Bricks99.repository;

import java.util.List;

import org.springframework.data.repository.PagingAndSortingRepository;

import com.marolix.Bricks99.entity.PropertyDetailsEntity;

public interface PropertyRepository extends PagingAndSortingRepository<PropertyDetailsEntity, Integer>{
	PropertyDetailsEntity findByPropertyName(String name);
	List<PropertyDetailsEntity> findByAddressEntitySurveyNo(String surveynumber);
	public List<PropertyDetailsEntity>findByAddressEntityLocality(String LocalityName);
	List<PropertyDetailsEntity> findByPropertyPriceLessThanEqual(double price);

}
