package com.marolix;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Bricks99ApplicationTests {

	@Test
	void contextLoads() {
	}

}
